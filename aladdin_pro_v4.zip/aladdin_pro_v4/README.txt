ALADDIN PRO V4 — manual Plus500 analysis
Open index.html using a web server (not file:// on iPhone).
DEMO mode uses synthetic candles and cannot be used for trading.
LIVE mode requires a backend endpoint /api/candles?symbol=...&interval=... returning Twelve Data-style JSON {values:[{datetime,open,high,low,close},...]}, newest first, >=201 bars.
Never put a Twelve Data API key into index.html. Store it on the server.
SPY is not the Plus500 US500 CFD. Check prices and contract sizing on Plus500.
V4 signal score is a simple heuristic, NOT a calibrated probability or guarantee.
